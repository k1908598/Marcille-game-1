let marcille, basilisk, staff, spark, lifeLeft,floor;
let speed =20;
let angle1=-20;

// let sparkvely=-9
// let sparkvelx=-9;

lifeLeft = 50;
function preload(){
  marcilleI = loadImage('pxArt 3.png');
  basiliskI = loadImage('pxArt.png');
}

// function create sparks
function createSpark(angle){
  spark = new Sprite(marcille.x, marcille.y, 10);
  spark.color = 'yellow';
  //spark.collider = 'k';
  // if (sparkvely==-10&&sparkvelx==0){
  //   sparkvely= -9;
  //   sparkvelx= 1;
  //   }
  // spark.vel.y=sparkvely;
  // spark.vel.x=sparkvelx;
  spark.vel.y = speed*sin(angle);
  spark.vel.x = speed*cos(angle);
}

function setup() {
  createCanvas(800, 600);
  background('gray');
  world.gravity.y = 10;

  //create floor
  floor = new Sprite(0,440, 3000, 10, 'static');


  // create a staff
  //staff = new Sprite(25,70,10,90);

  // create Marcille
  marcille = new Sprite(300,420);
  if (marcilleI){
    //marcille.img = marcilleI;
    marcilleI.resize(50,50);
    marcille.addImage(marcilleI);
  }

  //create Basilisk
  basilisk = new Sprite(500,335);
  if (basiliskI){
    basiliskI.resize(200,200);
    basilisk.addImage(basiliskI);
  }
  createSpark(0);
}

function draw() {
  print(lifeLeft);
  // clear();
  background('gray');
  textSize(12);
  fill('black');
  text("press left and right to control the movement of marcille, press up and down to control the movement of the staff", 300, 30);
  // modify text later

  //movement of basilisk
  if (lifeLeft>0){
    if (frameCount%240){
      basilisk.vel.y= random(-10,10);
      basilisk.vel.x=0;
      basilisk.angle=0;
    }
 }
  if (kb.pressing('left')){
    print('left');
    marcille.vel.x =-2;
  }
  if (kb.pressing('right')){
    marcille.vel.x=2;
  }
  // else{
  //   marcille.vel.x=0;
  // }

  //up or down
  if (kb.pressing('s')){
    //if (angle1<0){
      angle1-=10;
      print('down');
    //}

  }
  if (kb.pressing('w')){
    //if (angle1){
      angle1+=10;
      print(angle1);
      print('up');
    //}
  }




  //shotting spark based on seconds
  if (frameCount %60==0){
    createSpark(angle1);
  }

  //basilisk being hit
  if (spark.collide(basilisk)){
    spark.remove();
    lifeLeft--;
  }

  //spark disappear if it touches the floor
  if (spark.collide(floor)){
    print('hit')
    spark.remove();
  }

  //if (spark.overlaps(basilisk)){
    //spark.remove();
  //}
  

  //shows life left
  textSize(20);
  fill('black');
  text(lifeLeft, basilisk.x, basilisk.y-100);

  if (lifeLeft<0){
    textSize(50);
    fill('black');
    text('GAME OVER, YOU WON', 300,300);
  }
  
}